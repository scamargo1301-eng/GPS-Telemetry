const map = L.map('map').setView([4.7110, -74.0721], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {

    attribution: '&copy; OpenStreetMap'

}).addTo(map);

let markers = [];

async function cargarVehiculos() {

    const respuesta = await fetch("/vehicles");

    const vehiculos = await respuesta.json();

    markers.forEach(marker => map.removeLayer(marker));

    markers = [];

    const tbody = document.querySelector("#tablaVehiculos tbody");

    tbody.innerHTML = "";

    vehiculos.forEach(vehicle => {

        const marker = L.marker([

            vehicle.last_lat,
            vehicle.last_lng

        ]).addTo(map);

        marker.bindPopup(

            `<b>${vehicle.vehicle_id}</b><br>${vehicle.status}`

        );

        markers.push(marker);

        tbody.innerHTML += `

        <tr>

            <td>${vehicle.vehicle_id}</td>

            <td>${vehicle.status}</td>

            <td>${vehicle.last_lat}</td>

            <td>${vehicle.last_lng}</td>

            <td>${vehicle.last_seen}</td>

        </tr>

        `;

    });

}

cargarVehiculos();

setInterval(cargarVehiculos,5000);